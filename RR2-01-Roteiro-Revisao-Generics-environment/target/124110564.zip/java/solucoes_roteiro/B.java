package solucoes_roteiro;

public interface B<String> extends A<String>{
    
}
