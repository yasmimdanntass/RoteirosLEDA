package solucoes_roteiro;

import java.util.Collection;

public interface A<T>{
    public void m(T object);

}
