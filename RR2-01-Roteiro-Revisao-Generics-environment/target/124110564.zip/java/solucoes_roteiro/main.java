package solucoes_roteiro;

import java.util.ArrayList;
import java.util.Collection;

public class main {
    public static void main(String[] args) {
        
        A<String> a = new C<>();
        a.m("bla");

        Collection<String> s = new ArrayList<>();
        Collection<Integer> i = new ArrayList<>();
        C<String> b = new C<>();
        C<Integer> c = new C<>();
        b.n(i);
        c.o(i);
        c.p(i);
    }
}
