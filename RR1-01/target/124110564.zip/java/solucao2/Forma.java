package solucao2;

public interface Forma {
    public double getArea();
} 
